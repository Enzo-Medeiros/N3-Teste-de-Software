# N3 Teste de Software

Este projeto é um sistema web para registro e análise de exames de saúde fetal, utilizando um modelo de machine learning (fictício ou real) e banco de dados SQLite.

## Funcionalidades
- Interface web para cadastro de exames fetais
- Predição automática da saúde fetal (Normal, Suspeito, Patológico)
- Armazenamento dos registros em banco de dados
- API REST para consulta e cadastro de registros

## Instalação

1. Clone este repositório ou baixe os arquivos.
2. Instale as dependências (recomenda-se uso de ambiente virtual):

```bash
pip install -r requirements.txt
```

## Como rodar a aplicação

Execute o arquivo principal:

```bash
python app.py
```

Acesse a interface web em: [http://127.0.0.1:5001](http://127.0.0.1:5001)

## Uso da API

### Criar um novo registro (POST)
- Endpoint: `/registros`
- Método: `POST`
- Content-Type: `application/json`
- Body: JSON com os campos do exame e CPF

Exemplo:
```json
{
  "cpf": "12345678901",
  "baseline_value": 120,
  "accelerations": 0.003,
  "fetal_movement": 0.001,
  ... (demais campos do modelo) ...
}
```

### Consultar registros (GET)
- Endpoint: `/registros`
- Método: `GET`
- Parâmetro opcional: `cpf`

Exemplo:
```
GET /registros?cpf=12345678901
```

## Observações
- Se não houver um modelo real (`model.sav`), o sistema cria um modelo fictício para demonstração.
- O banco de dados é criado automaticamente na primeira execução. 