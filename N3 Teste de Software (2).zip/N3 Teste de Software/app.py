import os
import pickle
import pandas as pd
from flask import Flask, request, jsonify, render_template_string
from flask_sqlalchemy import SQLAlchemy
from sklearn.dummy import DummyClassifier
import datetime

# --- 1. CONFIGURAÇÃO INICIAL E CRIAÇÃO DO MODELO FICTÍCIO ---

# Nome do arquivo do modelo
MODEL_FILENAME = 'model.sav'

# Se o modelo não existir, cria um modelo fictício para que a aplicação possa rodar.
# Em um cenário real, você substituiria este bloco pelo seu arquivo `model.sav` treinado.
if not os.path.exists(MODEL_FILENAME):
    print(f"'{MODEL_FILENAME}' não encontrado. Criando um modelo fictício para demonstração.")
    # Define os nomes das 21 colunas que o modelo espera
    feature_names = [
        'baseline_value', 'accelerations', 'fetal_movement', 'uterine_contractions', 
        'light_decelerations', 'severe_decelerations', 'prolongued_decelerations', 
        'abnormal_short_term_variability', 'mean_value_of_short_term_variability', 
        'percentage_of_time_with_abnormal_long_term_variability', 
        'mean_value_of_long_term_variability', 'histogram_width', 'histogram_min', 
        'histogram_max', 'histogram_number_of_peaks', 'histogram_number_of_zeroes', 
        'histogram_mode', 'histogram_mean', 'histogram_median', 'histogram_variance', 
        'histogram_tendency'
    ]
    # Cria um modelo que sempre prevê a classe '1' (Normal)
    dummy_model = DummyClassifier(strategy='constant', constant=1)
    # "Treina" o modelo com uma linha de dados fictícios (zeros) para evitar erro de amostras inconsistentes
    dummy_model.fit(pd.DataFrame([[0]*len(feature_names)], columns=feature_names), [1])
    
    # Salva o modelo fictício no arquivo
    with open(MODEL_FILENAME, 'wb') as f:
        pickle.dump(dummy_model, f)
    print(f"Modelo fictício '{MODEL_FILENAME}' criado com sucesso.")

# --- 2. INICIALIZAÇÃO DA APLICAÇÃO FLASK E BANCO DE DADOS ---

app = Flask(__name__)

# Configuração do banco de dados SQLite
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# --- 3. CARREGAMENTO DO MODELO DE MACHINE LEARNING ---

# Carrega o modelo na memória. Isso é feito apenas uma vez quando o servidor inicia.
try:
    with open(MODEL_FILENAME, 'rb') as f:
        model = pickle.load(f)
    print("Modelo de Machine Learning carregado com sucesso.")
except FileNotFoundError:
    model = None
    print(f"ERRO CRÍTICO: O arquivo do modelo '{MODEL_FILENAME}' não foi encontrado.")
except Exception as e:
    model = None
    print(f"ERRO CRÍTICO: Falha ao carregar o modelo. Erro: {e}")

# Nomes das colunas na ordem que o modelo espera
MODEL_FEATURES = [
    'baseline_value', 'accelerations', 'fetal_movement', 'uterine_contractions',
    'light_decelerations', 'severe_decelerations', 'prolongued_decelerations',
    'abnormal_short_term_variability', 'mean_value_of_short_term_variability',
    'percentage_of_time_with_abnormal_long_term_variability',
    'mean_value_of_long_term_variability', 'histogram_width', 'histogram_min',
    'histogram_max', 'histogram_number_of_peaks', 'histogram_number_of_zeroes',
    'histogram_mode', 'histogram_mean', 'histogram_median',
    'histogram_variance', 'histogram_tendency'
]

# --- 4. DEFINIÇÃO DO MODELO DE DADOS (TABELA DO BANCO) ---

class Registro(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    cpf = db.Column(db.String(11), nullable=False)
    ts = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    
    # Campos de entrada do modelo
    baseline_value = db.Column(db.Float)
    accelerations = db.Column(db.Float)
    fetal_movement = db.Column(db.Float)
    uterine_contractions = db.Column(db.Float)
    light_decelerations = db.Column(db.Float)
    severe_decelerations = db.Column(db.Float)
    prolongued_decelerations = db.Column(db.Float)
    abnormal_short_term_variability = db.Column(db.Float)
    mean_value_of_short_term_variability = db.Column(db.Float)
    percentage_of_time_with_abnormal_long_term_variability = db.Column(db.Float)
    mean_value_of_long_term_variability = db.Column(db.Float)
    histogram_width = db.Column(db.Float)
    histogram_min = db.Column(db.Float)
    histogram_max = db.Column(db.Float)
    histogram_number_of_peaks = db.Column(db.Float)
    histogram_number_of_zeroes = db.Column(db.Float)
    histogram_mode = db.Column(db.Float)
    histogram_mean = db.Column(db.Float)
    histogram_median = db.Column(db.Float)
    histogram_variance = db.Column(db.Float)
    histogram_tendency = db.Column(db.Float)

    # Campo de saída do modelo
    fetal_health = db.Column(db.Integer, nullable=False)

    def to_dict(self):
        """Converte o objeto para um dicionário, útil para a serialização JSON."""
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}

# --- 5. DEFINIÇÃO DO FRONTEND (HTML, CSS, JS) ---

# O HTML é definido como uma string multi-linha para ser renderizado pelo Flask.
# Isso mantém tudo em um único arquivo.
HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Monitor de Saúde Fetal</title>
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif; background-color: #f4f7f9; color: #333; margin: 0; padding: 2rem; }
        .container { max-width: 900px; margin: auto; background: #fff; padding: 2rem; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
        h1 { color: #2c3e50; text-align: center; }
        .form-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1.5rem; }
        .form-group { display: flex; flex-direction: column; }
        label { font-weight: 600; margin-bottom: 0.5rem; color: #555; }
        input { padding: 0.75rem; border: 1px solid #ccc; border-radius: 4px; font-size: 1rem; transition: border-color 0.3s; }
        input:focus { border-color: #3498db; outline: none; }
        .cpf-group { grid-column: 1 / -1; } /* CPF ocupa a linha inteira */
        .submit-btn { grid-column: 1 / -1; padding: 1rem; background-color: #3498db; color: white; border: none; border-radius: 4px; font-size: 1.1rem; font-weight: bold; cursor: pointer; transition: background-color 0.3s; }
        .submit-btn:hover { background-color: #2980b9; }
        #result { margin-top: 2rem; padding: 1.5rem; border-radius: 8px; text-align: center; font-size: 1.2rem; font-weight: bold; display: none; }
        .success { background-color: #e8f5e9; color: #2e7d32; border: 1px solid #a5d6a7; }
        .error { background-color: #ffebee; color: #c62828; border: 1px solid #ef9a9a; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Registro de Exame Fetal</h1>
        <form id="exam-form">
            <div class="form-grid">
                <div class="form-group cpf-group">
                    <label for="cpf">CPF da Gestante</label>
                    <input type="text" id="cpf" name="cpf" required placeholder="Apenas números">
                </div>
                <!-- Campos do modelo -->
                {% for feature in features %}
                <div class="form-group">
                    <label for="{{ feature }}">{{ feature.replace('_', ' ').title() }}</label>
                    <input type="number" step="any" id="{{ feature }}" name="{{ feature }}" required>
                </div>
                {% endfor %}
                <button type="submit" class="submit-btn">Enviar e Analisar</button>
            </div>
        </form>
        <div id="result"></div>
    </div>

    <script>
        document.getElementById('exam-form').addEventListener('submit', async function(event) {
            event.preventDefault();

            const resultDiv = document.getElementById('result');
            resultDiv.style.display = 'none';
            resultDiv.className = '';

            const formData = new FormData(this);
            const data = {};
            // Converte os dados do formulário para um objeto JSON, transformando em números
            for (let [key, value] of formData.entries()) {
                data[key] = key === 'cpf' ? value : parseFloat(value);
            }

            try {
                const response = await fetch('/registros', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(data)
                });

                const responseData = await response.json();

                if (!response.ok) {
                    throw new Error(responseData.error || 'Ocorreu um erro desconhecido.');
                }
                
                // Mapeia o resultado numérico para texto
                let healthStatus;
                switch(responseData.fetal_health) {
                    case 1: healthStatus = 'Normal'; break;
                    case 2: healthStatus = 'Suspeito'; break;
                    case 3: healthStatus = 'Patológico'; break;
                    default: healthStatus = 'Desconhecido';
                }

                resultDiv.textContent = `Registro salvo com sucesso! ID: ${responseData.id}. Resultado do Exame: ${healthStatus}`;
                resultDiv.classList.add('success');

            } catch (error) {
                resultDiv.textContent = 'Erro ao processar a requisição: ' + error.message;
                resultDiv.classList.add('error');
            } finally {
                resultDiv.style.display = 'block';
                window.scrollTo(0, document.body.scrollHeight); // Rola para o final para ver o resultado
            }
        });
    </script>
</body>
</html>
"""

# --- 6. DEFINIÇÃO DAS ROTAS DA API E DA PÁGINA ---

@app.route('/', methods=['GET'])
def index():
    """Renderiza a página principal com o formulário."""
    return render_template_string(HTML_TEMPLATE, features=MODEL_FEATURES)

@app.route('/registros', methods=['POST'])
def create_registro():
    """Recebe dados do exame, faz a predição e salva no banco."""
    if not model:
        return jsonify({"error": "Modelo de inferência não está disponível"}), 503

    data = request.get_json()
    if not data or 'cpf' not in data:
        return jsonify({"error": "Dados inválidos ou CPF ausente"}), 400

    try:
        # Prepara os dados para o modelo, garantindo a ordem correta das colunas
        input_df = pd.DataFrame([data], columns=MODEL_FEATURES)
        
        # Realiza a predição
        prediction = model.predict(input_df)
        fetal_health_result = int(prediction[0])

        # Cria um novo objeto de registro com todos os dados recebidos
        novo_registro = Registro(
            **data,  # Desempacota todos os dados do JSON no objeto
            fetal_health=fetal_health_result
        )
        
        db.session.add(novo_registro)
        db.session.commit()
        
        return jsonify({
            "message": "Registro criado com sucesso!",
            "id": novo_registro.id,
            "fetal_health": fetal_health_result
        }), 201

    except KeyError as e:
        return jsonify({"error": f"Campo obrigatório ausente no JSON: {e}"}), 400
    except Exception as e:
        return jsonify({"error": f"Ocorreu um erro interno: {e}"}), 500

@app.route('/registros', methods=['GET'])
def get_registros():
    """Retorna todos os registros ou filtra por CPF."""
    cpf = request.args.get('cpf')
    
    if cpf:
        registros = Registro.query.filter_by(cpf=cpf).all()
    else:
        registros = Registro.query.all()
    
    return jsonify([reg.to_dict() for reg in registros])

# --- 7. EXECUÇÃO DA APLICAÇÃO ---

if __name__ == '__main__':
    # Cria as tabelas do banco de dados se não existirem
    with app.app_context():
        db.create_all()
    # Inicia o servidor de desenvolvimento do Flask
    app.run(debug=True, port=5001)
